"""
Gateway Electronics — Flask Backend
=====================================
All API routes for the website.
Connect to MongoDB Atlas by setting MONGO_URI in .env

Run locally:
  python app.py

For cPanel Python App:
  Entry point: app.py | Application root: backend/
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime, timezone
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app, origins=["*"])

# ── MongoDB Connection ──
MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/gateway")

try:
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=4000)
    client.server_info()
    db = client["gateway_electronics"]
    print("✅ MongoDB connected!")
except Exception as e:
    print(f"⚠️  MongoDB not connected: {e}")
    db = None


def serialize(doc):
    if doc is None:
        return None
    doc["_id"] = str(doc["_id"])
    return doc

def serialize_list(docs):
    return [serialize(d) for d in docs]

def ok(data=None, msg="Success", code=200):
    res = {"success": True, "message": msg}
    if data:
        res.update(data)
    return jsonify(res), code

def err(msg="Error", code=400):
    return jsonify({"success": False, "error": msg}), code

def now():
    return datetime.now(timezone.utc).isoformat()

def col(name):
    return db[name] if db else None


# ══════════════════════════════════════
#  HEALTH
# ══════════════════════════════════════

@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "db": "connected" if db else "disconnected", "time": now()})


# ══════════════════════════════════════
#  LAPTOPS
# ══════════════════════════════════════

@app.route("/api/laptops", methods=["GET"])
def get_laptops():
    c = col("laptops")
    if c is None:
        return ok({"laptops": []}, "DB not connected")
    brand = request.args.get("brand")
    search = request.args.get("search")
    query = {}
    if brand:
        query["brand"] = brand
    if search:
        query["$or"] = [
            {"name": {"$regex": search, "$options": "i"}},
            {"specs": {"$regex": search, "$options": "i"}}
        ]
    try:
        laptops = serialize_list(c.find(query).sort("created_at", -1))
        return ok({"laptops": laptops})
    except Exception as e:
        return err(str(e), 500)


@app.route("/api/laptops", methods=["POST"])
def add_laptop():
    c = col("laptops")
    data = request.get_json()
    required = ["brand", "name", "specs", "original_price", "selling_price", "condition"]
    for f in required:
        if not data.get(f):
            return err(f"Missing: {f}")
    brand_icons = {
        "apple": "fab fa-apple",
        "dell": "fas fa-laptop",
        "lenovo": "fas fa-laptop-code",
        "hp": "fas fa-laptop",
        "asus": "fas fa-laptop",
        "microsoft": "fab fa-microsoft"
    }
    doc = {
        "brand": data["brand"].lower(),
        "name": data["name"],
        "specs": data["specs"],
        "original_price": float(data["original_price"]),
        "selling_price": float(data["selling_price"]),
        "condition": data["condition"],
        "stock": int(data.get("stock", 1)),
        "badge": data.get("badge", ""),
        "icon": brand_icons.get(data["brand"].lower(), "fas fa-laptop"),
        "created_at": now()
    }
    try:
        if c is not None:
            result = c.insert_one(doc)
            doc["_id"] = str(result.inserted_id)
        return ok({"laptop": doc}, "Laptop added", 201)
    except Exception as e:
        return err(str(e), 500)


@app.route("/api/laptops/<lid>", methods=["GET"])
def get_laptop(lid):
    c = col("laptops")
    if c is None:
        return err("DB not connected", 503)
    try:
        doc = c.find_one({"_id": ObjectId(lid)})
        if not doc:
            return err("Not found", 404)
        return ok({"laptop": serialize(doc)})
    except Exception as e:
        return err(str(e), 500)


@app.route("/api/laptops/<lid>", methods=["PUT"])
def update_laptop(lid):
    c = col("laptops")
    if c is None:
        return err("DB not connected", 503)
    data = request.get_json()
    data["updated_at"] = now()
    if "original_price" in data:
        data["original_price"] = float(data["original_price"])
    if "selling_price" in data:
        data["selling_price"] = float(data["selling_price"])
    if "stock" in data:
        data["stock"] = int(data["stock"])
    if "brand" in data:
        data["brand"] = data["brand"].lower()
        brand_icons = {"apple":"fab fa-apple","dell":"fas fa-laptop","lenovo":"fas fa-laptop-code","hp":"fas fa-laptop","asus":"fas fa-laptop","microsoft":"fab fa-microsoft"}
        data["icon"] = brand_icons.get(data["brand"], "fas fa-laptop")
    try:
        res = c.update_one({"_id": ObjectId(lid)}, {"$set": data})
        if res.matched_count == 0:
            return err("Not found", 404)
        return ok(msg="Updated")
    except Exception as e:
        return err(str(e), 500)


@app.route("/api/laptops/<lid>", methods=["DELETE"])
def delete_laptop(lid):
    c = col("laptops")
    if c is None:
        return err("DB not connected", 503)
    try:
        res = c.delete_one({"_id": ObjectId(lid)})
        if res.deleted_count == 0:
            return err("Not found", 404)
        return ok(msg="Deleted")
    except Exception as e:
        return err(str(e), 500)


# ══════════════════════════════════════
#  ORDERS
# ══════════════════════════════════════

@app.route("/api/orders", methods=["POST"])
def place_order():
    c = col("orders")
    data = request.get_json()
    required = ["name", "phone", "email", "address"]
    for f in required:
        if not data.get(f):
            return err(f"Missing: {f}")
    doc = {
        "name": data["name"],
        "phone": data["phone"],
        "email": data["email"],
        "address": data["address"],
        "notes": data.get("notes", ""),
        "items": data.get("items", []),
        "total": float(data.get("total", 0)),
        "status": "new",
        "submitted_at": now()
    }
    try:
        if c is not None:
            c.insert_one(doc)
        return ok(msg="Order placed successfully!", code=201)
    except Exception as e:
        return err(str(e), 500)


@app.route("/api/orders", methods=["GET"])
def get_orders():
    c = col("orders")
    if c is None:
        return ok({"orders": []})
    try:
        orders = serialize_list(c.find().sort("submitted_at", -1).limit(200))
        return ok({"orders": orders})
    except Exception as e:
        return err(str(e), 500)


# ══════════════════════════════════════
#  SELL REQUESTS
# ══════════════════════════════════════

@app.route("/api/sell-requests", methods=["POST"])
def sell_request():
    c = col("sell_requests")
    data = request.get_json()
    if not data.get("name") or not data.get("phone"):
        return err("Name and phone are required")
    doc = {
        "name": data.get("name"),
        "phone": data.get("phone"),
        "email": data.get("email", ""),
        "brand": data.get("brand", ""),
        "model": data.get("model", ""),
        "condition": data.get("condition", ""),
        "description": data.get("description", ""),
        "status": "pending",
        "submitted_at": now()
    }
    try:
        if c is not None:
            c.insert_one(doc)
        return ok(msg="Sell request received! We'll contact you within 2 hours.", code=201)
    except Exception as e:
        return err(str(e), 500)


@app.route("/api/sell-requests", methods=["GET"])
def get_sell_requests():
    c = col("sell_requests")
    if c is None:
        return ok({"requests": []})
    try:
        items = serialize_list(c.find().sort("submitted_at", -1).limit(200))
        return ok({"requests": items})
    except Exception as e:
        return err(str(e), 500)


# ══════════════════════════════════════
#  CONTACT MESSAGES
# ══════════════════════════════════════

@app.route("/api/contact", methods=["POST"])
def contact():
    c = col("contact_messages")
    data = request.get_json()
    if not data.get("name") or not data.get("message"):
        return err("Name and message required")
    doc = {
        "name": data.get("name"),
        "phone": data.get("phone", ""),
        "email": data.get("email", ""),
        "message": data.get("message"),
        "submitted_at": now()
    }
    try:
        if c is not None:
            c.insert_one(doc)
        return ok(msg="Message received! We'll reply soon.")
    except Exception as e:
        return err(str(e), 500)


@app.route("/api/contact", methods=["GET"])
def get_contact():
    c = col("contact_messages")
    if c is None:
        return ok({"messages": []})
    try:
        items = serialize_list(c.find().sort("submitted_at", -1).limit(200))
        return ok({"messages": items})
    except Exception as e:
        return err(str(e), 500)


# ══════════════════════════════════════
#  SEED SAMPLE DATA
# ══════════════════════════════════════

def seed():
    if db is None:
        return
    c = db["laptops"]
    if c.count_documents({}) > 0:
        return
    samples = [
        {"brand":"apple","name":"Apple MacBook Pro 14 M3","specs":"Apple M3, 16GB RAM, 512GB SSD, 14 Liquid Retina","original_price":199900,"selling_price":110000,"condition":"Excellent","badge":"Best Seller","icon":"fab fa-apple","stock":2},
        {"brand":"apple","name":"Apple MacBook Air M2","specs":"Apple M2, 8GB RAM, 256GB SSD, 13.6 Retina","original_price":114900,"selling_price":62000,"condition":"Good","badge":"Popular","icon":"fab fa-apple","stock":3},
        {"brand":"dell","name":"Dell XPS 15 9520","specs":"Intel i7-12700H, 16GB RAM, 512GB SSD, 15.6 OLED","original_price":149900,"selling_price":72000,"condition":"Excellent","badge":"Hot Deal","icon":"fas fa-laptop","stock":2},
        {"brand":"dell","name":"Dell Inspiron 15 3520","specs":"Intel i5-1235U, 8GB RAM, 512GB SSD, 15.6 FHD","original_price":62990,"selling_price":29000,"condition":"Good","badge":"","icon":"fas fa-laptop","stock":4},
        {"brand":"lenovo","name":"Lenovo ThinkPad X1 Carbon Gen 11","specs":"Intel i7-1365U, 16GB RAM, 1TB SSD, 14 IPS","original_price":169990,"selling_price":82000,"condition":"Excellent","badge":"Premium","icon":"fas fa-laptop-code","stock":2},
        {"brand":"lenovo","name":"Lenovo IdeaPad Slim 5","specs":"AMD Ryzen 5 7530U, 16GB RAM, 512GB SSD, 15.6","original_price":67990,"selling_price":32000,"condition":"Good","badge":"","icon":"fas fa-laptop-code","stock":3},
        {"brand":"hp","name":"HP EliteBook 840 G10","specs":"Intel i7-1355U, 16GB RAM, 512GB SSD, 14 FHD","original_price":109990,"selling_price":52000,"condition":"Excellent","badge":"","icon":"fas fa-laptop","stock":2},
        {"brand":"hp","name":"HP Pavilion 15","specs":"Intel i5-1235U, 8GB RAM, 512GB SSD, 15.6 FHD","original_price":58990,"selling_price":27000,"condition":"Good","badge":"Value Pick","icon":"fas fa-laptop","stock":5},
        {"brand":"asus","name":"Asus ZenBook 14 OLED","specs":"Intel i5-1240P, 16GB RAM, 512GB SSD, 14 2.8K OLED","original_price":79990,"selling_price":38000,"condition":"Excellent","badge":"","icon":"fas fa-laptop","stock":2},
        {"brand":"asus","name":"Asus ROG Zephyrus G14","specs":"AMD Ryzen 9 7940HS, 16GB RAM, 1TB SSD, RTX 4060","original_price":129990,"selling_price":68000,"condition":"Good","badge":"Gaming","icon":"fas fa-laptop","stock":1},
        {"brand":"microsoft","name":"Microsoft Surface Laptop 5","specs":"Intel i5-1245U, 8GB RAM, 256GB SSD, 13.5 PixelSense","original_price":99999,"selling_price":48000,"condition":"Excellent","badge":"","icon":"fab fa-microsoft","stock":2},
        {"brand":"microsoft","name":"Microsoft Surface Pro 9","specs":"Intel i7-1255U, 16GB RAM, 256GB SSD, 13 PixelSense Flow","original_price":139999,"selling_price":69000,"condition":"Good","badge":"","icon":"fab fa-microsoft","stock":2},
    ]
    for s in samples:
        s["created_at"] = now()
    c.insert_many(samples)
    print(f"✅ Seeded {len(samples)} laptops")


if __name__ == "__main__":
    seed()
    print("🚀 Gateway Electronics API running on http://localhost:5000")
    app.run(host="0.0.0.0", port=5000, debug=True)
