/* =====================================================
   Gateway Electronics — app.js
   Frontend: products, cart, forms, animations
   ===================================================== */

const API = '/api';
const WA_NUMBER = '919994211512';

// ── SAMPLE LAPTOPS (fallback if API unavailable) ──
const SAMPLE_LAPTOPS = [
  {id:'s1',brand:'apple',name:'Apple MacBook Pro 14" M3',specs:'Apple M3, 16GB RAM, 512GB SSD, 14" Liquid Retina',original_price:199900,selling_price:110000,condition:'Excellent',badge:'Best Seller',icon:'fab fa-apple'},
  {id:'s2',brand:'apple',name:'Apple MacBook Air M2',specs:'Apple M2, 8GB RAM, 256GB SSD, 13.6" Retina',original_price:114900,selling_price:62000,condition:'Good',badge:'Popular',icon:'fab fa-apple'},
  {id:'s3',brand:'dell',name:'Dell XPS 15 9520',specs:'Intel i7-12700H, 16GB RAM, 512GB SSD, 15.6" OLED',original_price:149900,selling_price:72000,condition:'Excellent',badge:'Hot Deal',icon:'fas fa-laptop'},
  {id:'s4',brand:'dell',name:'Dell Inspiron 15 3520',specs:'Intel i5-1235U, 8GB RAM, 512GB SSD, 15.6" FHD',original_price:62990,selling_price:29000,condition:'Good',badge:'',icon:'fas fa-laptop'},
  {id:'s5',brand:'lenovo',name:'Lenovo ThinkPad X1 Carbon Gen 11',specs:'Intel i7-1365U, 16GB RAM, 1TB SSD, 14" IPS',original_price:169990,selling_price:82000,condition:'Excellent',badge:'Premium',icon:'fas fa-laptop-code'},
  {id:'s6',brand:'lenovo',name:'Lenovo IdeaPad Slim 5',specs:'AMD Ryzen 5 7530U, 16GB RAM, 512GB SSD, 15.6"',original_price:67990,selling_price:32000,condition:'Good',badge:'',icon:'fas fa-laptop-code'},
  {id:'s7',brand:'hp',name:'HP EliteBook 840 G10',specs:'Intel i7-1355U, 16GB RAM, 512GB SSD, 14" FHD',original_price:109990,selling_price:52000,condition:'Excellent',badge:'',icon:'fas fa-laptop'},
  {id:'s8',brand:'hp',name:'HP Pavilion 15',specs:'Intel i5-1235U, 8GB RAM, 512GB SSD, 15.6" FHD',original_price:58990,selling_price:27000,condition:'Good',badge:'Value Pick',icon:'fas fa-laptop'},
  {id:'s9',brand:'asus',name:'Asus ZenBook 14 OLED',specs:'Intel i5-1240P, 16GB RAM, 512GB SSD, 14" 2.8K OLED',original_price:79990,selling_price:38000,condition:'Excellent',badge:'',icon:'fas fa-laptop'},
  {id:'s10',brand:'asus',name:'Asus ROG Zephyrus G14',specs:'AMD Ryzen 9 7940HS, 16GB RAM, 1TB SSD, RTX 4060',original_price:129990,selling_price:68000,condition:'Good',badge:'Gaming',icon:'fas fa-laptop'},
  {id:'s11',brand:'microsoft',name:'Microsoft Surface Laptop 5',specs:'Intel i5-1245U, 8GB RAM, 256GB SSD, 13.5" PixelSense',original_price:99999,selling_price:48000,condition:'Excellent',badge:'',icon:'fab fa-microsoft'},
  {id:'s12',brand:'microsoft',name:'Microsoft Surface Pro 9',specs:'Intel i7-1255U, 16GB RAM, 256GB SSD, 13" PixelSense Flow',original_price:139999,selling_price:69000,condition:'Good',badge:'',icon:'fab fa-microsoft'},
];

let allLaptops = [];
let visibleCount = 8;
let activeFilter = 'all';
let cart = JSON.parse(localStorage.getItem('gw_cart') || '[]');

// ── INIT ──
document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  initParallax();
  initScrollAnimations();
  initCounters();
  initBrandFilters();
  updateCartBadge();
  loadLaptops();
  document.getElementById('backToTop').addEventListener('click', () => window.scrollTo({top:0,behavior:'smooth'}));
  window.addEventListener('scroll', onScroll);
});

// ── NAVBAR ──
function initNavbar() {
  const hamburger = document.getElementById('hamburger');
  const navLinks = document.getElementById('navLinks');
  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    navLinks.classList.toggle('open');
  });
  navLinks.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      hamburger.classList.remove('open');
      navLinks.classList.remove('open');
    });
  });
  // Active link on scroll
  const sections = document.querySelectorAll('section[id]');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        const link = document.querySelector(`.nav-link[href="#${e.target.id}"]`);
        if (link) link.classList.add('active');
      }
    });
  }, {threshold: 0.4});
  sections.forEach(s => observer.observe(s));
}

function onScroll() {
  const navbar = document.getElementById('navbar');
  const backBtn = document.getElementById('backToTop');
  if (window.scrollY > 80) navbar.classList.add('scrolled');
  else navbar.classList.remove('scrolled');
  if (window.scrollY > 400) backBtn.classList.add('visible');
  else backBtn.classList.remove('visible');
}

// ── PARALLAX ──
function initParallax() {
  const heroBg = document.getElementById('heroBg');
  if (!heroBg) return;
  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;
    heroBg.style.transform = `translateY(${scrollY * 0.25}px)`;
    document.querySelectorAll('[data-parallax]').forEach(el => {
      const speed = parseFloat(el.dataset.parallax);
      el.style.transform = `translateY(${scrollY * speed}px)`;
    });
  }, {passive: true});
}

// ── SCROLL ANIMATIONS ──
function initScrollAnimations() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach((e, i) => {
      if (e.isIntersecting) {
        setTimeout(() => e.target.classList.add('animated'), i * 80);
      }
    });
  }, {threshold: 0.12});
  document.querySelectorAll('[data-animate]').forEach(el => observer.observe(el));
}

// ── COUNTER ANIMATION ──
function initCounters() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.querySelectorAll('.as-num').forEach(el => {
          const target = parseInt(el.dataset.count);
          let current = 0;
          const step = Math.ceil(target / 50);
          const timer = setInterval(() => {
            current = Math.min(current + step, target);
            el.textContent = current;
            if (current >= target) clearInterval(timer);
          }, 30);
        });
        observer.unobserve(e.target);
      }
    });
  }, {threshold: 0.5});
  const aboutSection = document.querySelector('.about-visual');
  if (aboutSection) observer.observe(aboutSection);
}

// ── BRAND FILTERS (hero section) ──
function initBrandFilters() {
  document.querySelectorAll('.brand-item').forEach(item => {
    item.addEventListener('click', () => {
      const filter = item.dataset.filter;
      document.getElementById('laptops').scrollIntoView({behavior:'smooth'});
      setTimeout(() => {
        document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
        const pill = document.querySelector(`.filter-pill[data-filter="${filter}"]`);
        if (pill) { pill.classList.add('active'); activeFilter = filter; visibleCount = 8; renderLaptops(); }
      }, 600);
    });
  });
}

// ── LOAD LAPTOPS ──
async function loadLaptops() {
  try {
    const res = await fetch(`${API}/laptops`);
    if (res.ok) {
      const data = await res.json();
      if (data.laptops && data.laptops.length > 0) {
        allLaptops = data.laptops;
      } else {
        allLaptops = SAMPLE_LAPTOPS;
      }
    } else {
      allLaptops = SAMPLE_LAPTOPS;
    }
  } catch (e) {
    allLaptops = SAMPLE_LAPTOPS;
  }
  renderLaptops();
  initFilterPills();
}

function initFilterPills() {
  document.querySelectorAll('.filter-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      activeFilter = pill.dataset.filter;
      visibleCount = 8;
      renderLaptops();
    });
  });
  document.getElementById('loadMoreBtn').addEventListener('click', () => {
    visibleCount += 4;
    renderLaptops();
  });
}

function renderLaptops() {
  const grid = document.getElementById('laptopsGrid');
  const filtered = activeFilter === 'all' ? allLaptops : allLaptops.filter(l => l.brand === activeFilter);
  const visible = filtered.slice(0, visibleCount);
  const loadMoreWrap = document.getElementById('loadMoreWrap');

  if (visible.length === 0) {
    grid.innerHTML = '<div class="no-products"><i class="fas fa-laptop" style="font-size:3rem;color:var(--black5);margin-bottom:1rem"></i><p>No laptops found for this brand.</p></div>';
    loadMoreWrap.style.display = 'none';
    return;
  }

  grid.innerHTML = visible.map(laptop => {
    const discount = Math.round((1 - laptop.selling_price / laptop.original_price) * 100);
    const id = laptop._id || laptop.id;
    const icon = laptop.icon || 'fas fa-laptop';
    const waMsg = encodeURIComponent(`Hi! I'm interested in the ${laptop.name} listed at ₹${laptop.selling_price.toLocaleString('en-IN')} on Gateway Electronics.`);
    return `
    <div class="product-card" data-brand="${laptop.brand}">
      <div class="product-img">
        <i class="${icon}"></i>
        ${laptop.badge ? `<span class="product-badge">${laptop.badge}</span>` : ''}
        <span class="product-condition">${laptop.condition}</span>
      </div>
      <div class="product-body">
        <div class="product-brand">${laptop.brand.charAt(0).toUpperCase()+laptop.brand.slice(1)}</div>
        <div class="product-name">${laptop.name}</div>
        <div class="product-specs">${laptop.specs}</div>
        <div class="product-pricing">
          <span class="price-orig">MRP ₹${laptop.original_price.toLocaleString('en-IN')}</span>
          <div class="price-row">
            <span class="price-sell">₹${laptop.selling_price.toLocaleString('en-IN')}</span>
            <span class="price-discount">${discount}% OFF</span>
          </div>
        </div>
        <div class="product-actions">
          <button class="btn-add-cart" onclick="addToCart('${id}')">
            <i class="fas fa-shopping-bag"></i> Add to Cart
          </button>
          <a href="https://wa.me/${WA_NUMBER}?text=${waMsg}" target="_blank" class="btn-whatsapp-buy">
            <i class="fab fa-whatsapp"></i>
          </a>
        </div>
      </div>
    </div>`;
  }).join('');

  loadMoreWrap.style.display = filtered.length > visibleCount ? 'block' : 'none';

  // Animate cards in
  grid.querySelectorAll('.product-card').forEach((card, i) => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    card.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
    setTimeout(() => { card.style.opacity = '1'; card.style.transform = 'translateY(0)'; }, i * 60);
  });
}

// ── CART ──
function addToCart(id) {
  const laptop = allLaptops.find(l => (l._id || l.id) === id);
  if (!laptop) return;
  const existing = cart.find(c => c.id === id);
  if (existing) { existing.qty++; }
  else { cart.push({id, name: laptop.name, price: laptop.selling_price, icon: laptop.icon || 'fas fa-laptop', qty: 1}); }
  saveCart();
  showToast(`✅ ${laptop.name} added to cart!`, 'success');
}

function removeFromCart(id) {
  cart = cart.filter(c => c.id !== id);
  saveCart();
  renderCartDrawer();
}

function saveCart() {
  localStorage.setItem('gw_cart', JSON.stringify(cart));
  updateCartBadge();
  renderCartDrawer();
}

function updateCartBadge() {
  const total = cart.reduce((s, c) => s + c.qty, 0);
  document.getElementById('cartBadge').textContent = total;
}

document.getElementById('cartBtn').addEventListener('click', openCart);
function openCart() {
  renderCartDrawer();
  document.getElementById('cartDrawer').classList.add('open');
  document.getElementById('cartOverlay').classList.add('open');
}
function closeCart() {
  document.getElementById('cartDrawer').classList.remove('open');
  document.getElementById('cartOverlay').classList.remove('open');
}

function renderCartDrawer() {
  const body = document.getElementById('cartBody');
  const totalEl = document.getElementById('cartTotalAmt');
  if (!cart.length) {
    body.innerHTML = '<p class="cart-empty-msg"><i class="fas fa-shopping-bag" style="display:block;font-size:2.5rem;margin-bottom:1rem;color:var(--black5)"></i>Your cart is empty</p>';
    totalEl.textContent = '₹0';
    return;
  }
  let total = 0;
  body.innerHTML = cart.map(item => {
    total += item.price * item.qty;
    return `
    <div class="cart-item">
      <div class="ci-thumb"><i class="${item.icon}"></i></div>
      <div class="ci-info">
        <div class="ci-name">${item.name} × ${item.qty}</div>
        <div class="ci-price">₹${(item.price * item.qty).toLocaleString('en-IN')}</div>
      </div>
      <button class="ci-remove" onclick="removeFromCart('${item.id}')"><i class="fas fa-trash-alt"></i></button>
    </div>`;
  }).join('');
  totalEl.textContent = '₹' + total.toLocaleString('en-IN');
}

function proceedCheckout() {
  if (!cart.length) { showToast('Your cart is empty!', 'error'); return; }
  // Build order summary
  let summaryHTML = '<div class="order-summary">';
  let total = 0;
  cart.forEach(item => {
    const subtotal = item.price * item.qty;
    total += subtotal;
    summaryHTML += `<div class="order-summary-item"><span>${item.name} × ${item.qty}</span><span>₹${subtotal.toLocaleString('en-IN')}</span></div>`;
  });
  summaryHTML += `<div class="order-summary-item"><span>Total</span><span>₹${total.toLocaleString('en-IN')}</span></div></div>`;
  document.getElementById('orderSummary').innerHTML = summaryHTML;
  closeCart();
  openModal('orderModal');
}

// ── ORDER SUBMISSION ──
async function submitOrder(e) {
  e.preventDefault();
  const form = e.target;
  const data = {
    name: form.name.value,
    phone: form.phone.value,
    email: form.email.value,
    address: form.address.value,
    notes: form.notes.value,
    items: cart,
    total: cart.reduce((s, c) => s + c.price * c.qty, 0),
    submitted_at: new Date().toISOString()
  };
  const ok = await postData('orders', data);
  if (ok) {
    // Also send WhatsApp message
    const itemsText = cart.map(i => `${i.name} x${i.qty} = ₹${(i.price*i.qty).toLocaleString('en-IN')}`).join('%0A');
    const waMsg = encodeURIComponent(`Hi Gateway Electronics!%0ANew Order from ${data.name}%0APhone: ${data.phone}%0AAddress: ${data.address}%0A%0AItems:%0A${itemsText}%0A%0ATotal: ₹${data.total.toLocaleString('en-IN')}`);
    window.open(`https://wa.me/${WA_NUMBER}?text=${waMsg}`, '_blank');
    showToast('🎉 Order placed! We will contact you shortly.', 'success');
    cart = [];
    saveCart();
    closeModal('orderModal');
    form.reset();
  } else {
    showToast('Order submitted! We will contact you.', 'success');
    cart = [];
    saveCart();
    closeModal('orderModal');
    form.reset();
  }
}

// ── SELL FORM ──
async function submitSell(e) {
  e.preventDefault();
  const form = e.target;
  const data = {
    name: form.name.value,
    phone: form.phone.value,
    email: form.email.value,
    brand: form.brand.value,
    model: form.model.value,
    condition: form.condition.value,
    description: form.description.value,
    submitted_at: new Date().toISOString()
  };
  const ok = await postData('sell-requests', data);
  showToast(ok ? '✅ Quote request sent! We\'ll contact you within 2 hours.' : '✅ Request received! We\'ll contact you soon.', 'success');
  form.reset();
}

// ── CONTACT FORM ──
async function submitContact(e) {
  e.preventDefault();
  const form = e.target;
  const data = {
    name: form.name.value,
    phone: form.phone.value,
    email: form.email.value,
    message: form.message.value,
    submitted_at: new Date().toISOString()
  };
  const ok = await postData('contact', data);
  showToast(ok ? '✅ Message sent! We\'ll reply soon.' : '✅ Message received! We\'ll reply soon.', 'success');
  form.reset();
}

// ── API HELPERS ──
async function postData(endpoint, data) {
  try {
    const res = await fetch(`${API}/${endpoint}`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(data)
    });
    return res.ok;
  } catch (e) {
    return false;
  }
}

// ── MODALS ──
function openModal(id) {
  document.getElementById(id).classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
  document.body.style.overflow = '';
}
function closeModalOut(e, id) {
  if (e.target.id === id) closeModal(id);
}

// ── TOAST ──
function showToast(msg, type = '') {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.className = `toast ${type} show`;
  setTimeout(() => { toast.className = 'toast'; }, 3500);
}
