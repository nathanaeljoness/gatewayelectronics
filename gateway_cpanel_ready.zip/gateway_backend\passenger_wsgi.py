"""
passenger_wsgi.py — cPanel Python App Entry Point
===================================================
This file is required by GoDaddy cPanel's Python App (Phusion Passenger).
Place this in the Application Root you set in cPanel.

Steps in cPanel:
1. Go to "Setup Python App"
2. Create new application:
   - Python version: 3.x (latest available)
   - Application root: gateway/backend
   - Application URL: / (or /api)
   - Application startup file: passenger_wsgi.py
   - Application Entry point: application
3. Click Create
4. In the virtual environment terminal that appears, run:
   pip install flask flask-cors pymongo python-dotenv
5. Set environment variable:
   MONGO_URI = your MongoDB Atlas connection string
6. Click Restart
"""

import sys
import os

# Add the app directory to path
sys.path.insert(0, os.path.dirname(__file__))

# Load .env if present
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))
except:
    pass

from app import app as application
