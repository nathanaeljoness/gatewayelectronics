/* =====================================================
   Gateway Electronics — admin.js
   Admin panel: login, dashboard, CRUD
   ===================================================== */

const API = '../api';
const ADMIN_USER = 'gatewayelectronics';
const ADMIN_PASS = 'lexi.6002';

let allAdminLaptops = [];
let currentEditId = null;

// ── LOGIN ──
function doLogin(e) {
  e.preventDefault();
  const user = document.getElementById('loginUser').value.trim();
  const pass = document.getElementById('loginPass').value;
  if (user === ADMIN_USER && pass === ADMIN_PASS) {
    sessionStorage.setItem('gw_admin', '1');
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('dashboard').style.display = 'flex';
    loadDashboard();
  } else {
    document.getElementById('loginError').style.display = 'block';
  }
}

function doLogout() {
  sessionStorage.removeItem('gw_admin');
  document.getElementById('dashboard').style.display = 'none';
  document.getElementById('loginScreen').style.display = 'flex';
}

// Check if already logged in
window.addEventListener('DOMContentLoaded', () => {
  if (sessionStorage.getItem('gw_admin') === '1') {
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('dashboard').style.display = 'flex';
    loadDashboard();
  }
  // Sidebar nav
  document.querySelectorAll('.sn-item[data-page]').forEach(item => {
    item.addEventListener('click', e => {
      e.preventDefault();
      navigateTo(item.dataset.page);
    });
  });
});

function navigateTo(page) {
  document.querySelectorAll('.sn-item').forEach(i => i.classList.remove('active'));
  document.querySelector(`.sn-item[data-page="${page}"]`)?.classList.add('active');
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(`page-${page}`)?.classList.add('active');
  document.getElementById('pageTitle').textContent = {
    overview:'Overview', laptops:'Manage Laptops',
    orders:'Customer Orders', 'sell-requests':'Sell Requests', contacts:'Messages'
  }[page] || page;
  // Load data for page
  if (page === 'laptops') loadLaptopsTable();
  if (page === 'orders') loadTable('orders', 'ordersTable', renderOrdersTable);
  if (page === 'sell-requests') loadTable('sell-requests', 'sellTable', renderSellTable);
  if (page === 'contacts') loadTable('contact', 'contactsTable', renderContactsTable);
  // Close sidebar on mobile
  document.getElementById('sidebar').classList.remove('open');
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

// ── LOAD DASHBOARD ──
async function loadDashboard() {
  navigateTo('overview');
  const [laptops, orders, sell, contacts] = await Promise.all([
    fetchData('laptops'),
    fetchData('orders'),
    fetchData('sell-requests'),
    fetchData('contact'),
  ]);
  document.getElementById('stat-laptops').textContent = laptops?.length || 0;
  document.getElementById('stat-orders').textContent = orders?.length || 0;
  document.getElementById('stat-sell').textContent = sell?.length || 0;
  document.getElementById('stat-msgs').textContent = contacts?.length || 0;

  // Recent orders
  renderRecentOrders(orders?.slice(0,5) || []);
  renderRecentSell(sell?.slice(0,5) || []);
}

function renderRecentOrders(orders) {
  const el = document.getElementById('recentOrders');
  if (!orders.length) { el.innerHTML = '<p class="table-empty">No orders yet</p>'; return; }
  el.innerHTML = `<table><thead><tr><th>Name</th><th>Phone</th><th>Total</th><th>Date</th></tr></thead>
  <tbody>${orders.map(o => `
    <tr>
      <td>${o.name||'-'}</td>
      <td>${o.phone||'-'}</td>
      <td style="color:var(--white);font-weight:600">₹${(o.total||0).toLocaleString('en-IN')}</td>
      <td style="color:var(--grey3)">${formatDate(o.submitted_at)}</td>
    </tr>`).join('')}</tbody></table>`;
}

function renderRecentSell(items) {
  const el = document.getElementById('recentSell');
  if (!items.length) { el.innerHTML = '<p class="table-empty">No sell requests yet</p>'; return; }
  el.innerHTML = `<table><thead><tr><th>Name</th><th>Brand</th><th>Condition</th><th>Date</th></tr></thead>
  <tbody>${items.map(s => `
    <tr>
      <td>${s.name||'-'}</td>
      <td>${s.brand||'-'}</td>
      <td>${s.condition||'-'}</td>
      <td style="color:var(--grey3)">${formatDate(s.submitted_at)}</td>
    </tr>`).join('')}</tbody></table>`;
}

// ── LAPTOPS TABLE ──
async function loadLaptopsTable() {
  const data = await fetchData('laptops');
  allAdminLaptops = data || [];
  renderLaptopsTable(allAdminLaptops);
}

function renderLaptopsTable(laptops) {
  const el = document.getElementById('laptopsTable');
  if (!laptops.length) { el.innerHTML = '<p class="table-empty">No laptops yet. Click "Add Laptop" to get started.</p>'; return; }
  el.innerHTML = `<table>
    <thead><tr><th>Brand</th><th>Model</th><th>Specs</th><th>MRP</th><th>Sell Price</th><th>Condition</th><th>Stock</th><th>Actions</th></tr></thead>
    <tbody>${laptops.map(l => {
      const id = l._id || l.id;
      return `<tr>
        <td style="text-transform:capitalize">${l.brand}</td>
        <td style="font-weight:500">${l.name}</td>
        <td style="color:var(--grey3);font-size:.8rem;max-width:200px">${l.specs}</td>
        <td class="price-orig-cell">₹${(l.original_price||0).toLocaleString('en-IN')}</td>
        <td class="price-sell-cell">₹${(l.selling_price||0).toLocaleString('en-IN')}</td>
        <td><span class="status-badge ${l.condition==='Excellent'?'status-done':l.condition==='Good'?'status-pending':'status-new'}">${l.condition||'-'}</span></td>
        <td>${l.stock||0}</td>
        <td><div class="tbl-actions">
          <button class="btn-tbl" onclick="editLaptop('${id}')"><i class="fas fa-edit"></i></button>
          <button class="btn-tbl del" onclick="deleteLaptop('${id}')"><i class="fas fa-trash"></i></button>
        </div></td>
      </tr>`;
    }).join('')}</tbody></table>`;
}

function filterLaptopTable() {
  const search = document.getElementById('laptopSearch').value.toLowerCase();
  const brand = document.getElementById('brandFilter').value;
  const filtered = allAdminLaptops.filter(l => {
    const matchSearch = !search || l.name.toLowerCase().includes(search) || l.specs.toLowerCase().includes(search);
    const matchBrand = !brand || l.brand === brand;
    return matchSearch && matchBrand;
  });
  renderLaptopsTable(filtered);
}

// ── ADD / EDIT LAPTOP ──
function openLaptopModal(laptop = null) {
  currentEditId = null;
  document.getElementById('laptopModalTitle').innerHTML = '<i class="fas fa-plus"></i> Add Laptop';
  document.getElementById('laptopForm').reset();
  document.getElementById('laptopId').value = '';
  if (laptop) {
    currentEditId = laptop._id || laptop.id;
    document.getElementById('laptopModalTitle').innerHTML = '<i class="fas fa-edit"></i> Edit Laptop';
    document.getElementById('laptopId').value = currentEditId;
    document.getElementById('lBrand').value = laptop.brand || '';
    document.getElementById('lName').value = laptop.name || '';
    document.getElementById('lSpecs').value = laptop.specs || '';
    document.getElementById('lOrigPrice').value = laptop.original_price || '';
    document.getElementById('lSellPrice').value = laptop.selling_price || '';
    document.getElementById('lCondition').value = laptop.condition || '';
    document.getElementById('lStock').value = laptop.stock || '';
    document.getElementById('lBadge').value = laptop.badge || '';
  }
  openModal('laptopModal');
}

function editLaptop(id) {
  const laptop = allAdminLaptops.find(l => (l._id || l.id) === id);
  if (laptop) openLaptopModal(laptop);
}

async function saveLaptop(e) {
  e.preventDefault();
  const form = e.target;
  // Set brand-based icon
  const brandIconMap = {apple:'fab fa-apple',dell:'fas fa-laptop',lenovo:'fas fa-laptop-code',hp:'fas fa-laptop',asus:'fas fa-laptop',microsoft:'fab fa-microsoft'};
  const brand = form.brand.value;
  const data = {
    brand,
    name: form.name.value,
    specs: form.specs.value,
    original_price: parseFloat(form.original_price.value),
    selling_price: parseFloat(form.selling_price.value),
    condition: form.condition.value,
    stock: parseInt(form.stock.value),
    badge: form.badge.value,
    icon: brandIconMap[brand] || 'fas fa-laptop',
  };

  const id = document.getElementById('laptopId').value;
  let ok;
  if (id) {
    ok = await putData(`laptops/${id}`, data);
    showToast(ok ? '✅ Laptop updated!' : '✅ Updated (demo mode)', 'success');
  } else {
    ok = await postData('laptops', data);
    showToast(ok ? '✅ Laptop added!' : '✅ Added (demo mode)', 'success');
  }
  closeModal('laptopModal');
  loadLaptopsTable();
}

async function deleteLaptop(id) {
  if (!confirm('Delete this laptop? This cannot be undone.')) return;
  const ok = await deleteData(`laptops/${id}`);
  showToast(ok ? '✅ Deleted!' : '✅ Deleted (demo mode)', 'success');
  loadLaptopsTable();
}

// ── OTHER TABLES ──
async function loadTable(endpoint, elementId, renderFn) {
  const data = await fetchData(endpoint);
  renderFn(data || [], elementId);
}

function renderOrdersTable(orders, elId) {
  const el = document.getElementById(elId);
  if (!orders.length) { el.innerHTML = '<p class="table-empty">No orders yet</p>'; return; }
  el.innerHTML = `<table>
    <thead><tr><th>Name</th><th>Phone</th><th>Email</th><th>Items</th><th>Total</th><th>Address</th><th>Date</th></tr></thead>
    <tbody>${orders.map(o => `<tr>
      <td>${o.name||'-'}</td>
      <td>${o.phone||'-'}</td>
      <td style="color:var(--grey3)">${o.email||'-'}</td>
      <td style="color:var(--grey3);font-size:.8rem">${Array.isArray(o.items)?o.items.map(i=>`${i.name} x${i.qty}`).join(', '):'-'}</td>
      <td class="price-sell-cell">₹${(o.total||0).toLocaleString('en-IN')}</td>
      <td style="color:var(--grey3);font-size:.8rem;max-width:160px">${o.address||'-'}</td>
      <td style="color:var(--grey3)">${formatDate(o.submitted_at)}</td>
    </tr>`).join('')}</tbody></table>`;
}

function renderSellTable(items, elId) {
  const el = document.getElementById(elId);
  if (!items.length) { el.innerHTML = '<p class="table-empty">No sell requests yet</p>'; return; }
  el.innerHTML = `<table>
    <thead><tr><th>Name</th><th>Phone</th><th>Brand</th><th>Model</th><th>Condition</th><th>Description</th><th>Date</th></tr></thead>
    <tbody>${items.map(s => `<tr>
      <td>${s.name||'-'}</td>
      <td>${s.phone||'-'}</td>
      <td style="text-transform:capitalize">${s.brand||'-'}</td>
      <td>${s.model||'-'}</td>
      <td>${s.condition||'-'}</td>
      <td style="color:var(--grey3);font-size:.8rem;max-width:180px">${s.description||'-'}</td>
      <td style="color:var(--grey3)">${formatDate(s.submitted_at)}</td>
    </tr>`).join('')}</tbody></table>`;
}

function renderContactsTable(items, elId) {
  const el = document.getElementById(elId);
  if (!items.length) { el.innerHTML = '<p class="table-empty">No messages yet</p>'; return; }
  el.innerHTML = `<table>
    <thead><tr><th>Name</th><th>Phone</th><th>Email</th><th>Message</th><th>Date</th></tr></thead>
    <tbody>${items.map(c => `<tr>
      <td>${c.name||'-'}</td>
      <td>${c.phone||'-'}</td>
      <td style="color:var(--grey3)">${c.email||'-'}</td>
      <td style="color:var(--grey3);font-size:.8rem;max-width:220px">${c.message||'-'}</td>
      <td style="color:var(--grey3)">${formatDate(c.submitted_at)}</td>
    </tr>`).join('')}</tbody></table>`;
}

// ── API HELPERS ──
async function fetchData(endpoint) {
  try {
    const res = await fetch(`${API}/${endpoint}`);
    if (!res.ok) return null;
    const data = await res.json();
    return data.laptops || data.orders || data.requests || data.messages || data.items || data || null;
  } catch { return null; }
}
async function postData(endpoint, data) {
  try {
    const res = await fetch(`${API}/${endpoint}`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    return res.ok;
  } catch { return false; }
}
async function putData(endpoint, data) {
  try {
    const res = await fetch(`${API}/${endpoint}`, {method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    return res.ok;
  } catch { return false; }
}
async function deleteData(endpoint) {
  try {
    const res = await fetch(`${API}/${endpoint}`, {method:'DELETE'});
    return res.ok;
  } catch { return false; }
}

// ── UTILS ──
function formatDate(dateStr) {
  if (!dateStr) return '-';
  try {
    return new Date(dateStr).toLocaleDateString('en-IN', {day:'2-digit',month:'short',year:'numeric'});
  } catch { return dateStr; }
}
function openModal(id) {
  document.getElementById(id).classList.add('open');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}
function closeModalOut(e, id) {
  if (e.target.id === id) closeModal(id);
}
function showToast(msg, type='') {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.className = `toast ${type} show`;
  setTimeout(() => { toast.className = 'toast'; }, 3000);
}
